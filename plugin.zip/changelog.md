# ChangeLogs

## 1.0.0

- JavaScript plugin template
- Latest `acode-plugin-types`, esbuild, and `plugin.zip` packaging
